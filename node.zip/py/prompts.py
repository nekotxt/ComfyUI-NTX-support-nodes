from comfy_api.latest import ComfyExtension, io, ui

from ruamel.yaml import YAML

import numpy as np
import torch
from PIL import Image, ImageOps

from ..config_variables import ADDON_NAME, ADDON_PREFIX, ADDON_CATEGORY, API_PREFIX, SETTINGS_DIR
from .logging import logger
from .utils import notify_user, DICT_TYPE

# ===== PROMPT LIBRARY =====================================================================================================================

# directory holding the nested prompt library files. Every *.yaml / *.yml file in
# here is scanned and merged: dictionary keys are treated as nested categories and
# list items as the leaves of the tree.
PROMPTS_DIR = SETTINGS_DIR / "prompts"

# shown in the combobox when the file is missing or empty, so the node still loads
NO_PROMPTS_OPTION = "(no prompts found)"

# image extensions looked up (in order) next to a prompt id, e.g. scenes/fantasy/dungeon.png
IMAGE_EXTENSIONS = (".png", ".jpeg", ".jpg")

# name separator to be used in leaf strings to identify a name
NAME_SEPARATOR = "::"

# keys of a dictionary entry that are not extra parameters: "name" is the id and
# "positive" is the prompt. Every other key:value pair is exposed as a parameter.
RESERVED_KEYS = ("name", "positive")

def _flatten_prompts(node, prefix, out, params):
    """Recursively walk the parsed YAML, building an ordered {id: prompt} map.
    Dict keys extend the category path; only list items become leaves. A list item
    is either a plain string (used both as the combobox label and the prompt), or a
    dictionary with a "name" key (shown in the combobox) and a "positive" key (the
    prompt text). e.g. clothing: [T-shirt] -> {"clothing/T-shirt": "T-shirt"}.
    Bare scalars (a key mapping to a single value) are ignored.

    A dictionary entry may additionally carry any number of extra keys (anything
    besides "name" and "positive"); those are collected into `params` as
    {id: {key: value}} for LoadPromptAdvanced."""
    if isinstance(node, dict):
        for key, value in node.items():
            new_prefix = f"{prefix}/{key}" if prefix else str(key)
            _flatten_prompts(value, new_prefix, out, params)
    elif isinstance(node, (list, tuple)):
        for item in node:
            if isinstance(item, dict) and "name" in item:
                leaf = str(item["name"])
                key = f"{prefix}/{leaf}" if prefix else leaf
                out[key] = str(item.get("positive", leaf))
                entry = {k: str(v) for k, v in item.items()
                         if k not in RESERVED_KEYS and v is not None}
                if entry:
                    params[key] = entry
            elif isinstance(item, (dict, list, tuple)):
                _flatten_prompts(item, prefix, out, params)
            else:
                leaf = str(item)
                text = leaf
                if NAME_SEPARATOR in leaf:
                    leaf, text = leaf.split(NAME_SEPARATOR, 1)
                key = f"{prefix}/{leaf}" if prefix else leaf
                out[key] = text


# cached results of _build_prompts_map(); populated lazily on the first
# load_prompts_map() call. Call reload_prompts_map() to rebuild from disk.
# _PROMPTS_CACHE is the {id: prompt} map; _PARAMS_CACHE is the parallel
# {id: {paramN: value}} map (only ids that define at least one param appear).
_PROMPTS_CACHE = None
_PARAMS_CACHE = None

def load_prompts_map():
    """Return the merged {id: prompt} map, building it from disk on first use and
    caching it afterwards. Use reload_prompts_map() to pick up file changes."""
    global _PROMPTS_CACHE, _PARAMS_CACHE
    if _PROMPTS_CACHE is None:
        _PROMPTS_CACHE, _PARAMS_CACHE = _build_prompts_map()
    return _PROMPTS_CACHE


def load_prompts_params():
    """Return the {id: {paramN: value}} map, building the cache if needed."""
    load_prompts_map()  # ensures both caches are populated together
    return _PARAMS_CACHE


def reload_prompts_map():
    """Discard the cache and rebuild the maps from disk on the next access."""
    global _PROMPTS_CACHE, _PARAMS_CACHE
    _PROMPTS_CACHE, _PARAMS_CACHE = _build_prompts_map()
    return _PROMPTS_CACHE


def _build_prompts_map():
    """Build the merged, ordered ({id: prompt}, {id: {paramN: value}}) maps from PROMPTS_DIR.

    Two sources are combined:
    - every *.yaml / *.yml file in PROMPTS_DIR (top level), flattened into category
      paths; files sharing a structure accumulate under the same path (e.g.
      artists/finnish/Jarno Trulli from one file joins artists/finnish from another).
    - every *.txt file found recursively inside SUBDIRECTORIES of PROMPTS_DIR
      (.txt files sitting directly in PROMPTS_DIR are ignored); the file's relative
      path without extension becomes the id and its text content the prompt, e.g.
      scenes/fantasy/castle.txt -> {"scenes/fantasy/castle": "<file content>"}."""
    out = {}
    params = {}
    if not PROMPTS_DIR.is_dir():
        logger.warning(f"LoadPrompt : prompts directory not found : {PROMPTS_DIR}")
        return out, params

    # YAML files (top level only)
    yaml = YAML(typ="rt")
    for path in sorted(PROMPTS_DIR.glob("*.yaml")) + sorted(PROMPTS_DIR.glob("*.yml")):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.load(f)
            if data is not None:
                _flatten_prompts(data, "", out, params)
        except Exception as e:
            logger.warning(f"LoadPrompt : could not read prompts file {path.name} : {e}")

    # TXT files inside subdirectories (recursive); those directly in PROMPTS_DIR are ignored
    for path in sorted(PROMPTS_DIR.rglob("*.txt")):
        rel = path.relative_to(PROMPTS_DIR)
        if len(rel.parts) < 2:
            continue  # directly in PROMPTS_DIR — skip
        key = rel.with_suffix("").as_posix()
        try:
            out[key] = path.read_text(encoding="utf-8")
        except Exception as e:
            logger.warning(f"LoadPrompt : could not read prompt file {rel.as_posix()} : {e}")

    if not out:
        logger.warning(f"LoadPrompt : no prompts found in : {PROMPTS_DIR}")
    return out, params


def load_prompt_ids():
    """The list of leaf ids used to populate the combobox."""
    ids = list(load_prompts_map().keys())
    ids.sort()
    return ids if ids else [NO_PROMPTS_OPTION]


# ===== PROMPT IMAGES ======================================================================================================================

def find_prompt_image(id):
    """Return the Path of the image sitting next to the given prompt id (matching
    name, one of IMAGE_EXTENSIONS), or None if no such file exists. The lookup is
    confined to PROMPTS_DIR so an id cannot reach files outside the library."""
    if not id:
        return None
    base = PROMPTS_DIR.joinpath(*id.split("/"))
    try:
        base.resolve().relative_to(PROMPTS_DIR.resolve())
    except ValueError:
        logger.warning(f"LoadPrompt : ignoring out-of-library id : {id}")
        return None
    for ext in IMAGE_EXTENSIONS:
        candidate = base.with_name(base.name + ext)
        if candidate.is_file():
            return candidate
    return None


def load_image_as_tensor(path):
    """Load an image file into a ComfyUI IMAGE tensor of shape [1, H, W, 3], float32 0..1."""
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)
    img = img.convert("RGB")
    arr = np.array(img).astype(np.float32) / 255.0
    return torch.from_numpy(arr)[None, ]


# ===== NODES ==============================================================================================================================

class LoadPromptBase(io.ComfyNode):
    """Shared behaviour of the LoadPrompt* nodes: the library-backed id combobox,
    the library-text fallback and the per-id preview image lookup. Not registered
    as a node itself."""

    @classmethod
    def id_input(cls):
        # standard combo carrying the id list in its schema. define_schema() runs
        # on every node-definitions fetch (page load, "Refresh Node Definitions"),
        # so the library is re-read from disk here and prompts added on disk show
        # up without a backend restart.
        reload_prompts_map()
        return io.Combo.Input("id", options=load_prompt_ids())

    @classmethod
    def validate_inputs(cls, id):
        # ids come and go with the files on disk, so a saved workflow may carry a
        # value no longer in the combo options; any string is accepted and
        # execute() falls back gracefully when an id is unknown
        return True

    @classmethod
    def resolve_prompt(cls, id, prompt):
        # the frontend fills the prompt box from the selected id, but fall back to
        # the library text when it is empty (e.g. headless / API execution)
        if not prompt or prompt.isspace():
            prompt = load_prompts_map().get(id, "")
        return prompt

    @classmethod
    def load_prompt_image(cls, id):
        # look for an image with the same name as the id; return None if missing
        image_path = find_prompt_image(id)
        if image_path is None:
            return None
        try:
            return load_image_as_tensor(image_path)
        except Exception as e:
            logger.warning(f"{cls.__name__} : could not load image {image_path.name} : {e}")
            return None


class LoadPrompt(LoadPromptBase):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id=f"{ADDON_PREFIX}LoadPrompt",
            display_name=f"{ADDON_PREFIX} Load Prompt",
            description="Pick a prompt from the nested prompt library (input/ntx_data/prompts: *.yaml files and *.txt files in subfolders); the text can be edited before use.",
            category=f"{ADDON_CATEGORY}/prompts",
            inputs=[
                cls.id_input(),
                io.String.Input("prompt", multiline=True, default=""),
            ],
            outputs=[
                io.String.Output("prompt"),
                io.String.Output("id"),
                io.Image.Output("image"),
            ],
        )

    @classmethod
    def execute(cls, id, prompt):
        prompt = cls.resolve_prompt(id, prompt)
        return io.NodeOutput(prompt, id, cls.load_prompt_image(id))


class LoadPromptAdvanced(LoadPromptBase):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id=f"{ADDON_PREFIX}LoadPromptAdvanced",
            display_name=f"{ADDON_PREFIX} Load Prompt Advanced",
            description="Pick a prompt from the nested prompt library (input/ntx_data/prompts); the text can be edited before use. Adds three free-form string parameters passed straight through to the outputs (auto-filled from the entry's extra keys by the frontend), plus a params dictionary with all the extra key:value pairs of the selected entry.",
            category=f"{ADDON_CATEGORY}/prompts",
            inputs=[
                cls.id_input(),
                io.String.Input("prompt", multiline=True, default=""),
                io.String.Input("param1", default=""),
                io.String.Input("param2", default=""),
                io.String.Input("param3", default=""),
            ],
            outputs=[
                io.String.Output("prompt"),
                io.String.Output("id"),
                io.Image.Output("image"),
                io.String.Output("param1"),
                io.String.Output("param2"),
                io.String.Output("param3"),
                DICT_TYPE.Output("params"),
            ],
        )

    @classmethod
    def execute(cls, id, prompt, param1, param2, param3):
        prompt = cls.resolve_prompt(id, prompt)
        # the three string parameters are repeated as outputs; params carries every
        # extra key:value pair of the selected entry (empty for plain-string leaves)
        params = load_prompts_params().get(id, {})
        return io.NodeOutput(prompt, id, cls.load_prompt_image(id), param1, param2, param3, params)


class LoadPromptChar(LoadPromptBase):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id=f"{ADDON_PREFIX}LoadPromptChar",
            display_name=f"{ADDON_PREFIX} Load Prompt Char",
            description="Pick a character prompt from the nested prompt library (input/ntx_data/prompts); the text can be edited before use and is returned as 'char', together with the 'save_name' string.",
            category=f"{ADDON_CATEGORY}/prompts",
            inputs=[
                cls.id_input(),
                io.String.Input("prompt", multiline=True, default=""),
                io.String.Input("save_name", default=""),
            ],
            outputs=[
                io.String.Output("char"),
                io.String.Output("save_name"),
            ],
        )

    @classmethod
    def execute(cls, id, prompt, save_name):
        prompt = cls.resolve_prompt(id, prompt)
        return io.NodeOutput(prompt, save_name)


# ===== SAVING PROMPTS =====================================================================================================================

def prompt_target_paths(category, name):
    """Build the (txt_path, img_path) a prompt with the given category/name would be
    saved to, e.g. category="scenes/fantasy", name="lake" -> scenes/fantasy/lake.{txt,jpg}.
    Returns None when the name is empty or the target would fall outside PROMPTS_DIR."""
    name = (name or "").strip().strip("/")
    cat_parts = [p for p in (category or "").split("/") if p.strip()]
    if not name:
        return None
    base = PROMPTS_DIR.joinpath(*cat_parts, name)
    try:
        base.resolve().relative_to(PROMPTS_DIR.resolve())
    except ValueError:
        return None
    return (base.with_name(base.name + ".txt"), base.with_name(base.name + ".jpg"))


def save_tensor_as_image(image, path):
    """Save a ComfyUI IMAGE tensor ([B,H,W,C] or [H,W,C], float 0..1) to an image
    file; the format follows the path extension (first frame only for a batch)."""
    img = image[0] if image.ndim == 4 else image
    arr = (img.clamp(0.0, 1.0).cpu().numpy() * 255.0).round().astype(np.uint8)
    Image.fromarray(arr).save(path)


def save_prompt_files(category, name, prompt, image=None, overwrite=False):
    """Write the prompt text (and the image, if given) to the library.
    Returns (ok, status); status is "saved", "exists" (txt present and not overwrite),
    or an error message."""
    paths = prompt_target_paths(category, name)
    if paths is None:
        return (False, "invalid category/name")
    txt_path, img_path = paths

    if txt_path.exists() and not overwrite:
        return (False, "exists")

    try:
        txt_path.parent.mkdir(parents=True, exist_ok=True)
        txt_path.write_text(prompt or "", encoding="utf-8")
        if image is not None:
            save_tensor_as_image(image, img_path)
    except Exception as e:
        return (False, f"could not save : {e}")

    # the library changed on disk — drop the cache so the new entry shows up
    global _PROMPTS_CACHE
    _PROMPTS_CACHE = None
    return (True, "saved")


class SavePrompt(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id=f"{ADDON_PREFIX}SavePrompt",
            display_name=f"{ADDON_PREFIX} Save Prompt",
            description="Save a prompt (and an optional image) into the library under category/name, e.g. scenes/fantasy/lake.txt (+ .jpg).",
            category=f"{ADDON_CATEGORY}/prompts",
            is_output_node=True,
            inputs=[
                io.String.Input("category", default=""),
                io.String.Input("name", default=""),
                io.String.Input("prompt", multiline=True, default=""),
                io.Boolean.Input("overwrite", default=False),
                io.Image.Input("image", optional=True),
            ],
            outputs=[],
        )

    @classmethod
    def fingerprint_inputs(cls, **kwargs):
        # always re-run so the file is (re)written every time the node is executed
        return float("nan")

    @classmethod
    def execute(cls, category, name, prompt, overwrite=False, image=None):
        ok, status = save_prompt_files(category, name, prompt, image, overwrite)
        target = f"{category.strip('/')}/{name}".strip("/") if name else "(unnamed)"

        if ok:
            logger.info(f"SavePrompt : saved {target}")
            return io.NodeOutput(ui=ui.PreviewText(f"Saved {target}"))

        if status == "exists":
            msg = f"'{target}' already exists — not saved (enable 'overwrite' to replace it)"
            logger.warning(f"SavePrompt : {msg}")
            notify_user("warn", "Save Prompt", msg)
            return io.NodeOutput(ui=ui.PreviewText(msg))

        msg = f"could not save '{target}' : {status}"
        logger.warning(f"SavePrompt : {msg}")
        notify_user("error", "Save Prompt", msg)
        return io.NodeOutput(ui=ui.PreviewText(msg))


# ===== INITIALIZATION =====================================================================================================================

def get_nodes_list() -> list[type[io.ComfyNode]]:
    return [
        LoadPrompt,
        LoadPromptAdvanced,
        LoadPromptChar,
        SavePrompt,
    ]

# ===== JAVASCRIPT API =====================================================================================================================

from aiohttp import web
from server import PromptServer

@PromptServer.instance.routes.get(f"/{API_PREFIX}/load_prompts")
async def load_prompts_route(request):
    return web.json_response(load_prompts_map())

@PromptServer.instance.routes.get(f"/{API_PREFIX}/load_prompt_ids")
async def load_prompt_ids_route(request):
    # plain id-list endpoint (the combo itself now ships its options in the node
    # schema); rebuilds the maps from disk so callers always see the current files
    reload_prompts_map()
    return web.json_response(load_prompt_ids())

@PromptServer.instance.routes.get(f"/{API_PREFIX}/view_prompt_image")
async def view_prompt_image_route(request):
    # preview image sitting next to a prompt id, used by the tree picker;
    # find_prompt_image() confines the lookup to PROMPTS_DIR
    image_path = find_prompt_image(request.query.get("id", ""))
    if image_path is None:
        raise web.HTTPNotFound()
    return web.FileResponse(image_path)

@PromptServer.instance.routes.get(f"/{API_PREFIX}/load_prompt_params")
async def load_prompt_params_route(request):
    return web.json_response(load_prompts_params())

@PromptServer.instance.routes.post(f"/{API_PREFIX}/reload_prompts")
async def reload_prompts_route(request):
    return web.json_response(reload_prompts_map())

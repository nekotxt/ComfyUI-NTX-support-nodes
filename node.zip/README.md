Utility nodes to support the creation of pipes in ComfyUI :

- DictSet* => assign a value of the specified type to the pipe
- DictGet* => retrieve a value of the specified type from the pipe

THese nodes are meant to be encased into subgraphs, to create customized pipes.
